import java.util.*;
import java.net.*;
import java.io.*;

 class CP extends Thread
{
   BufferedReader socreader;
   PrintWriter socwriter;
   int timedelay=0;
   private String pid,msgFromClient;
   public static int nodecount;
   HashMap<String,String> noderes=new HashMap<String,String>();
   public CP(String pid, Socket socket)
   {
      System.out.println(pid+" -> "+socket);
      noderes.put("proid_1","Unknown");
      noderes.put("proid_2","Unknown");
      noderes.put("proid_3","Unknown");
       this.pid=pid;
       try
       {
           socreader=new BufferedReader(new InputStreamReader(socket.getInputStream())); 
           socwriter=new PrintWriter(new OutputStreamWriter(socket.getOutputStream()),true);
           ++nodecount;
          
       }catch(Exception e)
       {
          System.out.println("Client connect error: "+e);
       }
      }
      public static int getProcessCounter()
      {
        return nodecount;
      }
      public void sendMessage(String sendmsg)
      {
        try
        {
               socwriter.println(sendmsg);
               System.out.println("Message to "+pid+" -> "+sendmsg);
        }catch(Exception e)
        {

        }
      }

      public String receiveMessagey()
      {
       try
       {
         Thread t=new Thread()
         {
           public void run()
           {
           msgFromClient=null;
           while(msgFromClient==null)
           {
           try
           {
             timedelay++;
             if(timedelay==10)             //verification of timer dealy
             {
                if(noderes.get(pid)!="Yes")
                    {
                  timedelay=0;
                  System.out.println(pid+" not responding");
                  System.out.println("=>due timeout "+pid+" response is abort");
                  //System.out.println("timeout due to "+pid+" not responded ");
                 // System.out.println("-> Reply from "+pid+" is abort");
                  msgFromClient="abort";
                    }
                    else
                    {
                        //break;
                    }
             }
             else
             {
              msgFromClient=socreader.readLine();
              noderes.put(pid,msgFromClient);
              System.out.println("Reply from "+pid+" -> "+msgFromClient);
              timedelay=0;
              Thread.sleep(1000);
             } 
           }catch(Exception e)
           {
             //System.out.println("thread error:"+e);
             //break;
             System.out.println(pid+" disconnected");
             try
             {
               Thread.sleep(1000);
             }catch(Exception e1)
             {

             }
           }   
         }  
         }
          
           
       };
       t.start();
       t.join();
      }catch(Exception e)
      {
       System.out.println("Read error:"+e);
      }
      return msgFromClient;
     }
     public void pendingNodeTransaction(String proid,Socket socket)
     {
        try
        {
            String pendingmsg="";
          if(noderes.get(proid).equalsIgnoreCase("Yes"))
          {
                pendingmsg="commit";
          }
          else
          {
                pendingmsg="abort";
          }
          BufferedReader socketreader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
          PrintWriter socketwriter=new PrintWriter(new OutputStreamWriter(socket.getOutputStream()),true); 
          socketwriter.println(pendingmsg);
          System.out.println("Message to "+proid+" -> "+pendingmsg);
          String msgFromClient=socketreader.readLine();
          System.out.println("Reply from "+proid+" -> "+msgFromClient);
      
    
        }catch(Exception e)
        {
            System.out.println(e);
        }
     }

   }


 class PC extends  Thread
{
private int clientcommit,updatedValue;    
ClientProcess2PC process1,process2,process3;
String processid;
BufferedReader buffread;
BufferedWriter buffwrite;
File file;
private static void writeCommitValueToFile(File file, int value) throws IOException {
  try (FileWriter fwriter = new FileWriter(file)) {
      fwriter.write(Integer.toString(value));
  }
}

private static int readCommitValueFromFile(File file) throws IOException {
try (BufferedReader bread = new BufferedReader(new FileReader(file))) {
  return Integer.parseInt(bread.readLine());
}
}
                                        
public PC(String processid)
{
     
    file=new File("manager_log.txt");
    if(file.exists())
    {
     try
     {
      //String data= new String(Files.readAllBytes(file.toPath()));
      buffread=new BufferedReader(new FileReader("manager_log.txt"));
      String line=buffread.readLine();
      clientcommit=Integer.parseInt(line);
      buffread.close();   
     }catch(Exception e)
     {
         System.out.println("manager_log file read error:"+e);
     }
    }
    else
    {
     try
     {
         buffwrite=new BufferedWriter(new FileWriter("manager_log.txt"));
         buffwrite.write("0");
         clientcommit=0;
         buffwrite.close();
     }catch(Exception e)
     {
         System.out.println("manager_log file write error:"+e);
     }
    }

   
     this.processid=processid;                                             
     new Timer().schedule(new TimerTask() {
      public void run() {
      if(ClientProcess2PC.getProcessCounter()==3)                  //verification for 3 client process are ready
     {
        System.out.println("3 Client Paricipants are ready to start 2PC protocal");
        start();
        this.cancel();
    }
  }
 }, 0, 2200);
}

public void run()                 
{
  
           System.out.println("Server 2PC communication started:");
           try
           {
            if(clientcommit==0)
            {
                  System.out.println("Prepare Voting");
                  Thread.sleep(3000);
                  process1.sendMessage("Prepare Voting");
                  process2.sendMessage("Prepare Voting");
                  process3.sendMessage("Prepare Voting");
                  String msg_1=process1.receiveMessagey();
                  String msg_2=process2.receiveMessagey();
                  String msg_3=process3.receiveMessagey();

                  if(msg_1.equalsIgnoreCase("Yes")&& msg_2.equalsIgnoreCase("Yes") && msg_3.equalsIgnoreCase("Yes"))
                  {
                    process1.sendMessage("commit");
                    updatedValue = readCommitValueFromFile(file) + 1;
                    writeCommitValueToFile(file,updatedValue);
                    Thread.sleep(2500);

                    process2.sendMessage("commit");
                    updatedValue = readCommitValueFromFile(file) + 1;
                    writeCommitValueToFile(file,updatedValue);
                    Thread.sleep(2500);

                    process3.sendMessage("commit");
                    updatedValue = readCommitValueFromFile(file) + 1;
                    writeCommitValueToFile(file,updatedValue);
                    Thread.sleep(2500);
                  }
                  else
                  {
                    process1.sendMessage("abort");
                    Thread.sleep(2500);
                    process2.sendMessage("abort");
                    Thread.sleep(2500);
                    process3.sendMessage("abort");
                    Thread.sleep(2500);
                  }
                }
                else
                {
                  process1.sendMessage("commit");
                  updatedValue = readCommitValueFromFile(file) + 1;
                  writeCommitValueToFile(file,updatedValue);
                  Thread.sleep(2500);

                  process2.sendMessage("commit");
                  updatedValue = readCommitValueFromFile(file) + 1;
                  writeCommitValueToFile(file,updatedValue);
                  Thread.sleep(2500);

                  process3.sendMessage("commit");
                  updatedValue = readCommitValueFromFile(file) + 1;
                  writeCommitValueToFile(file,updatedValue);
                  Thread.sleep(2500);
                }
                  process1.receiveMessagey();
                  process2.receiveMessagey();
                  process3.receiveMessagey();
                  writeCommitValueToFile(file,0);
                  

        }catch(Exception e)
        {
            System.out.println("Error in Client Communication:"+e);
        }
}



}

public class Manager
{
    public static void main(String args[])throws Exception 
    {
    ServerSocket ss=new ServerSocket(9999);

        TwoPauseProtocal twophauseprotocalc= new TwoPauseProtocal("Server");

        while(true)
     {
        Socket s=ss.accept();
        System.out.println("Connection:->"+s);
        new Thread()
        {
          
          public void run()
          {
           try
              {
              BufferedReader socread=new BufferedReader(new InputStreamReader(s.getInputStream()));
              String p_id=socread.readLine();
              System.out.println("Client Joining to 2PC:"+p_id);
              int nodecount=ClientProcess2PC.getProcessCounter();
              if(p_id.equalsIgnoreCase("proid_1") && nodecount>=3){
                twophauseprotocalc.process1.pendingNodeTransaction(p_id,s);
              }
              else if(p_id.equalsIgnoreCase("proid_1") )
              {
                    twophauseprotocalc.process1=new ClientProcess2PC(p_id,s);
              }
              else if(p_id.equalsIgnoreCase("proid_2")&& nodecount>=3){
                twophauseprotocalc.process2.pendingNodeTransaction(p_id,s);
              }
              else if(p_id.equalsIgnoreCase("proid_2") ){
                   twophauseprotocalc.process2=new ClientProcess2PC(p_id,s);
              }
              else if(p_id.equalsIgnoreCase("proid_3") && nodecount>=3){
                twophauseprotocalc.process3.pendingNodeTransaction(p_id,s);
              }
              else if(p_id.equalsIgnoreCase("proid_3")){
                    twophauseprotocalc.process3=new ClientProcess2PC(p_id,s);
           }
                 }catch(Exception e)
            {
              System.out.println("Error in Client_Thread Joining:"+e);
            }
          }
          
        }.start();

     }
    }

}


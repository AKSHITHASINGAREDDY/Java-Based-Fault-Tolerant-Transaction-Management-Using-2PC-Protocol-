
//Client paricipant process1 Program
import java.util.*;
import java.net.*;
import java.io.*;

class CP {
	Socket s;
	InputStream sin;
	OutputStream sout;
	BufferedReader socRead;
	PrintWriter socWrite;
	int least = 1, most = 9, counttimer = 0,reConnect=0;
	Random random = new Random();
	String msgFromManager="",pID,timeOutTxt="";

	public CP(String pID) {
		try {
			this.pID=pID;
			s = new Socket("localhost", 9999);
			System.out.println("Connection :->" + s);
			sin = s.getInputStream();
			sout = s.getOutputStream();
			socRead = new BufferedReader(new InputStreamReader(sin));
			socWrite = new PrintWriter(new OutputStreamWriter(sout), true);
			socWrite.println(pID);
		} catch (Exception e) {
			System.out.println("Client Process Constructor error:" + e);
		}
	}

	public void communicateToManager() {
		try {

			int rand = random.nextInt(most - least + 1) + least;
			// new Timer().schedule(new TimerTask() {
			// public void run() {
			while (true) {
				try {
					// ----------------------------
					new Timer().schedule(new TimerTask() {
						public void run() {
							try {
								counttimer++;
								if (counttimer == 22) 
								{
									counttimer = 0;
									System.out.println("Timeout due to Manager not responded ");
									timeOutTxt="abort"; 
									this.cancel();
									return;
								} else {
									msgFromManager = socRead.readLine();
									counttimer = 0;
									this.cancel();
									return;
								}
							} catch (Exception e) {
								// System.out.println("Read from server delay error:"+e);
								if (reConnect == 0) {
									reConnect++;
                       					new Thread()  {
											public void run(){								
												while (true) {
												try {
												s = new Socket("localhost", 9999);
												System.out.println("Re-Connecting to Manager :" + s);
												sin = s.getInputStream();
												sout = s.getOutputStream();
												
												socRead = new BufferedReader(new InputStreamReader(s.getInputStream()));
												socWrite = new PrintWriter(new OutputStreamWriter(sout), true);
												socWrite.println(pID);
												if (reConnect == 1) {
													reConnect=0;
												}
												break;
											} catch (IOException e1) {
											//	System.out.println("Coordinator not responding: " + e1);
											System.out.println("Manager disconnected");
												try {
													Thread.sleep(1000);
												} catch (Exception e2) {
													System.out.println("Error: " + e2);
												}
											}
										}
	 								 }
									}.start();

								this.cancel();
								return;
							}
						}// catch close
					}
					}, 0, 2000);
					// ----------

					if(msgFromManager.length()>0)
                    {
					System.out.println("Server msg:" + msgFromManager);
                    }
					if (msgFromManager.equalsIgnoreCase("Prepare Voting")  && timeOutTxt.equalsIgnoreCase("abort")) {
					
							socWrite.println("Denied");
							System.out.println("Process_1:-> Response Denied Due to TimeOut");
						msgFromManager="";
						timeOutTxt="";
					}
					else if (msgFromManager.equalsIgnoreCase("Prepare Voting")  ) {
						if (rand % 7 != 0) {
							socWrite.println("Yes");
							System.out.println("Process_1:-> response Yes");
						} else {
							//System.out.println("Random no:"+rand);
							socWrite.println("Denied");
							System.out.println("Process_1:-> Response Denied");
						}
						msgFromManager="";
					}

					else if (msgFromManager.equalsIgnoreCase("commit")) {
						socWrite.println("Task Completed and lock released");
						System.out.println("Process_1:-> Response Task Completed and lock released");
						 //break;
						 msgFromManager="";
					} else if (msgFromManager.equalsIgnoreCase("abort")) {
						socWrite.println("Task aborted and lock released");
						System.out.println("Process_1:-> Response Task aborted and lock released");
						 //break;
						 msgFromManager="";
					}
				} catch (Exception e) {
					System.out.println("communicateToManager inner error:" + e);
					break;
				}
				Thread.sleep(4500);
			}
			// }
			// }, 0, 2000);

		} catch (Exception e) {
			System.out.println("communicateToManager error:" + e);
		}

	}
}

public class Process1 {

	public static void main(String[] args) {
		ClientProcesse2PC cc = new ClientProcesse2PC("proid_1");
		cc.communicateToManager();
	}

}
